export const greener = {
  "greener-dark": {
    primary: "#8FE385", // Red
    secondary: "#BBF4A5", // Melon
    accent: "#a3e08e", // Purple
    neutral: "#222222", // Very Dark Gray
    info: "#4BC0C0", // Turquoise
    success: "#77DD77", // Pastel Green
    warning: "#FFA500", // Orange
    error: "#E53935", // Red
    "base-100": "#333333", // Dark Gray
    "base-200": "#2C2C2C", // Charcoal
    "base-300": "#41423C", // Darker Gray
    "base-content": "#FFFFFF", // Updated to a lighter shade for better contrast in dark mode
    "--rounded-box": "0",
    "--rounded-btn": "0.1em",
    "--rounded-badge": "0",
    "--tab-radius": "0",
    "color-scheme": "dark",
  },
  "greener-light": {
    primary: "#8FE385", // Red
    secondary: "#BBF4A5", // Melon
    accent: "#a3e08e", // Purple
    neutral: "#ffffff", // Very Dark Gray
    info: "#81C784", // Light Green
    success: "#A5D6A7", // Pale Green
    warning: "#FFB74D", // Darker Orange
    error: "#E57373", // Light Red
    "base-100": "#F5F5F5", // Light Gray
    "base-200": "#F9F9F9", // Off White
    "base-300": "#E0E0E0", // Lighter Gray
    "base-content": "#262626", // Updated to a darker shade for better contrast in light mode
    "--rounded-box": "0",
    "--rounded-btn": "0.2em",
    "--rounded-badge": "0",
    "--tab-radius": "0",
    "color-scheme": "light",
  },
};
