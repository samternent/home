<script setup lang="ts">
import { useRouter } from "vue-router";
import { useAppApi } from "@/app/api";
import { Button, Card } from "ternent-ui/primitives";

const appApi = useAppApi();
const router = useRouter();

async function relaunchOnboarding(): Promise<void> {
  await appApi.identity.lock();
  await router.push("/");
}
</script>

<template>
  <section class="mx-auto w-full max-w-3xl p-6" data-test="launch-v2">
    <Card padding="lg">
      <p class="m-0 text-xs uppercase tracking-[0.18em] text-[var(--ui-fg-muted)]">
        Launch
      </p>
      <h2 class="m-0 mt-2 text-2xl font-semibold text-[var(--ui-fg)]">
        Identity onboarding is now global
      </h2>
      <p class="m-0 mt-3 text-sm leading-6 text-[var(--ui-fg-muted)]">
        The onboarding and unlock flow is handled by the AppShell dialog. If you need to run it
        again, lock the current identity.
      </p>
      <div class="mt-4 flex gap-2">
        <Button variant="secondary" @click="relaunchOnboarding">
          Lock And Reopen Onboarding
        </Button>
      </div>
    </Card>
  </section>
</template>
