<script setup lang="ts">
import { SButton, SCard } from "ternent-ui/components";
</script>

<template>
  <div class="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-6 py-8">
    <header class="mb-14 flex items-center justify-between border-b border-border pb-4">
      <div>
        <h1 class="m-0 text-2xl">Portable Proof</h1>
        <p class="m-0 text-sm text-fg-muted">by ternent.dev</p>
      </div>
      <a href="https://ternent.dev" target="_blank" rel="noreferrer" class="text-sm text-fg-muted hover:text-fg">
        ternent.dev
      </a>
    </header>

    <main class="flex-1">
      <SCard class="space-y-6 p-8">
        <div class="space-y-3">
          <h2 class="m-0 text-3xl">Sign and verify proofs locally in your browser.</h2>
          <p class="m-0 max-w-3xl text-fg-muted">
            Portable Proof lets you generate or import an identity, sign text or a single file, export a proof JSON,
            and verify that proof offline.
          </p>
        </div>

        <div class="flex flex-wrap gap-3">
          <SButton variant="primary" to="/app">Open App</SButton>
          <SButton variant="secondary" to="/app/verify">Verify a Proof</SButton>
        </div>

        <p class="m-0 text-sm text-fg-muted">CLI support is coming soon.</p>
      </SCard>
    </main>

    <footer class="mt-12 flex items-center justify-between border-t border-border pt-4 text-sm text-fg-muted">
      <a href="https://ternent.dev" target="_blank" rel="noreferrer" class="hover:text-fg">ternent.dev</a>
      <a href="https://github.com" target="_blank" rel="noreferrer" class="hover:text-fg">GitHub</a>
    </footer>
  </div>
</template>
