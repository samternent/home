<script setup lang="ts">
import { computed, ref } from "vue";
import { SButton, SCard } from "ternent-ui/components";
import {
  useIdentitySession,
  useIdentityCreate,
  useIdentityImport,
  useIdentityExport,
} from "@/modules/identity";

const { identity, hasIdentity, rememberInBrowser, setRememberInBrowser, clearIdentity } = useIdentitySession();
const { create, isCreating } = useIdentityCreate();
const { importIdentity, isImporting } = useIdentityImport();
const { downloadExport } = useIdentityExport();

const importPayload = ref("");
const importFileName = ref<string | null>(null);
const showImportPanel = ref(false);
const notice = ref<string | null>(null);
const error = ref<string | null>(null);

const rememberModel = computed({
  get: () => rememberInBrowser.value,
  set: (value: boolean) => {
    setRememberInBrowser(value);
    notice.value = value
      ? "Identity persistence enabled for this browser."
      : "Identity persistence disabled. Active identity stays in memory only.";
  },
});

const compactPublicKey = computed(() => {
  if (!identity.value?.publicKeyPem) return "";
  const key = identity.value.publicKeyPem;
  if (key.length <= 96) return key;
  return `${key.slice(0, 64)}...${key.slice(-32)}`;
});

const onGenerate = async () => {
  error.value = null;
  notice.value = null;

  try {
    await create();
    notice.value = "Identity created. Export it now and store it securely.";
  } catch (caught) {
    error.value = caught instanceof Error ? caught.message : "Failed to generate identity.";
  }
};

const onImport = async () => {
  error.value = null;
  notice.value = null;

  try {
    await importIdentity(importPayload.value);
    importPayload.value = "";
    importFileName.value = null;
    showImportPanel.value = false;
    notice.value = "Identity imported successfully.";
  } catch (caught) {
    error.value = caught instanceof Error ? caught.message : "Failed to import identity.";
  }
};

const onImportFile = async (event: Event) => {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;

  importFileName.value = file.name;
  importPayload.value = await file.text();
};

const onClear = () => {
  clearIdentity();
  notice.value = "Identity cleared from memory and remembered storage.";
  error.value = null;
};
</script>

<template>
  <section class="space-y-5">
    <header>
      <h2 class="m-0 text-2xl">Identity</h2>
      <p class="mt-2 text-sm text-fg-muted">Generate or import the active identity used to sign proofs.</p>
    </header>

    <SCard class="space-y-3 p-5">
      <label class="flex items-center gap-2 text-sm">
        <input v-model="rememberModel" type="checkbox" />
        Remember identity in this browser
      </label>
      <p class="m-0 text-xs text-fg-muted">
        Default behavior is memory-only. Enable this only on devices you trust.
      </p>
    </SCard>

    <SCard v-if="!hasIdentity" class="space-y-4 p-5">
      <h3 class="m-0 text-xl">No identity loaded</h3>
      <p class="m-0 text-sm text-fg-muted">Create a new identity or import an existing export payload.</p>

      <div class="flex flex-wrap gap-2">
        <SButton variant="primary" :loading="isCreating" @click="onGenerate">
          {{ isCreating ? "Generating..." : "Generate new identity" }}
        </SButton>
        <SButton variant="secondary" @click="showImportPanel = !showImportPanel">
          {{ showImportPanel ? "Hide import" : "Import identity" }}
        </SButton>
      </div>
    </SCard>

    <SCard v-else class="space-y-4 p-5">
      <h3 class="m-0 text-xl">Active identity</h3>
      <div class="grid gap-2 text-sm">
        <div><strong>Fingerprint:</strong> <span class="font-mono">{{ identity?.fingerprint }}</span></div>
        <div><strong>Public key:</strong> <span class="font-mono text-xs">{{ compactPublicKey }}</span></div>
      </div>

      <p class="m-0 rounded-md border border-danger bg-danger-muted px-3 py-2 text-sm">
        Export includes private key material. Store it securely.
      </p>

      <div class="flex flex-wrap gap-2">
        <SButton variant="primary" @click="downloadExport">Export identity</SButton>
        <SButton variant="secondary" @click="showImportPanel = !showImportPanel">
          {{ showImportPanel ? "Hide import" : "Replace / import identity" }}
        </SButton>
        <SButton variant="error" @click="onClear">Clear identity</SButton>
      </div>
    </SCard>

    <SCard v-if="showImportPanel" class="space-y-4 p-5">
      <h3 class="m-0 text-xl">Import identity</h3>
      <p class="m-0 text-sm text-fg-muted">Paste JSON export payload or PEM private key text.</p>

      <input type="file" accept=".json,.pem,text/plain,application/json" @change="onImportFile" />
      <p v-if="importFileName" class="m-0 text-xs text-fg-muted">Loaded file: {{ importFileName }}</p>

      <textarea
        v-model="importPayload"
        class="min-h-56 w-full rounded-md border border-border bg-surface px-3 py-2 font-mono text-xs"
        placeholder='{"privateKeyPem":"-----BEGIN PRIVATE KEY-----..."}'
      />

      <div class="flex gap-2">
        <SButton variant="primary" :loading="isImporting" @click="onImport">
          {{ isImporting ? "Importing..." : "Import" }}
        </SButton>
        <SButton variant="ghost" @click="showImportPanel = false">Cancel</SButton>
      </div>
    </SCard>

    <p v-if="notice" class="m-0 rounded-md border border-border bg-surface px-3 py-2 text-sm">{{ notice }}</p>
    <p v-if="error" class="m-0 rounded-md border border-danger bg-danger-muted px-3 py-2 text-sm">{{ error }}</p>
  </section>
</template>
