<script setup lang="ts">
import { computed } from "vue";
import { RouterLink, useRoute } from "vue-router";
import { useIdentitySession } from "@/modules/identity";
import OfflineBanner from "@/modules/offline/components/OfflineBanner.vue";

const route = useRoute();
const { identity, hasIdentity } = useIdentitySession();

const tabs = [
  { to: "/app/identity", label: "Identity" },
  { to: "/app/sign", label: "Sign" },
  { to: "/app/verify", label: "Verify" },
];

const fingerprintLabel = computed(() => {
  if (!identity.value?.fingerprint) return "No identity loaded";
  const value = identity.value.fingerprint;
  return `${value.slice(0, 16)}...${value.slice(-8)}`;
});

const currentPath = computed(() => route.path);
</script>

<template>
  <div class="mx-auto flex min-h-screen w-full max-w-6xl flex-col px-6 py-6">
    <header class="mb-5 rounded-xl border border-border bg-surface px-5 py-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="m-0 text-xl">Portable Proof</h1>
          <p class="m-0 text-sm text-fg-muted">by ternent.dev</p>
        </div>

        <div class="text-right text-sm">
          <div class="font-semibold">{{ hasIdentity ? "Active identity" : "Identity" }}</div>
          <div class="font-mono text-xs text-fg-muted">{{ fingerprintLabel }}</div>
        </div>
      </div>

      <div class="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
        <nav class="flex flex-wrap gap-2">
          <RouterLink
            v-for="tab in tabs"
            :key="tab.to"
            :to="tab.to"
            class="rounded-md px-3 py-2 text-sm"
            :class="
              currentPath.startsWith(tab.to)
                ? 'bg-primary-muted text-fg'
                : 'text-fg-muted hover:bg-surface-hover hover:text-fg'
            "
          >
            {{ tab.label }}
          </RouterLink>
        </nav>

        <RouterLink to="/" class="text-sm text-fg-muted hover:text-fg">Back to home</RouterLink>
      </div>
    </header>

    <OfflineBanner class="mb-5" />

    <main class="flex-1">
      <RouterView />
    </main>
  </div>
</template>
