<script setup lang="ts">
import { computed, ref } from "vue";
import { SButton, SCard } from "ternent-ui/components";
import { hashBytes, hashData } from "ternent-utils";
import {
  parsePortableProofJson,
  verifyPortableProofSignature,
  type PortableProofV1,
} from "@/modules/proof";

type VerificationMode = "proof-only" | "proof-and-content";
type ContentMode = "text" | "file";

type StageOneResult = {
  status: "idle" | "valid" | "invalid";
  errors: string[];
  fingerprint?: string;
  contentHash?: string;
};

type StageTwoResult = {
  status: "idle" | "match" | "mismatch" | "error" | "skipped";
  message?: string;
  providedHash?: string;
};

const proofJsonInput = ref("");
const proofFile = ref<File | null>(null);

const verificationMode = ref<VerificationMode>("proof-only");
const contentMode = ref<ContentMode>("text");
const contentText = ref("");
const contentFile = ref<File | null>(null);

const isVerifying = ref(false);
const stageOne = ref<StageOneResult>({ status: "idle", errors: [] });
const stageTwo = ref<StageTwoResult>({ status: "idle" });

const parsedProof = ref<PortableProofV1 | null>(null);

const stageOneTone = computed(() => {
  if (stageOne.value.status === "valid") return "border-success bg-surface";
  if (stageOne.value.status === "invalid") return "border-danger bg-danger-muted";
  return "border-border bg-surface";
});

const stageTwoTone = computed(() => {
  if (stageTwo.value.status === "match") return "border-success bg-surface";
  if (stageTwo.value.status === "mismatch" || stageTwo.value.status === "error") return "border-danger bg-danger-muted";
  return "border-border bg-surface";
});

const onProofFileInput = (event: Event) => {
  const input = event.target as HTMLInputElement;
  proofFile.value = input.files?.[0] || null;
};

const onContentFileInput = (event: Event) => {
  const input = event.target as HTMLInputElement;
  contentFile.value = input.files?.[0] || null;
};

const loadProofJson = async (): Promise<string> => {
  if (proofJsonInput.value.trim()) return proofJsonInput.value;
  if (proofFile.value) return proofFile.value.text();
  throw new Error("Upload a proof JSON file or paste proof JSON.");
};

const verifyContentMatch = async (proof: PortableProofV1): Promise<StageTwoResult> => {
  if (verificationMode.value === "proof-only") {
    return { status: "skipped", message: "Content match skipped (proof-only mode)." };
  }

  try {
    let providedHash = "";

    if (contentMode.value === "text") {
      if (!contentText.value.trim()) {
        return { status: "error", message: "Provide text content to compare." };
      }
      providedHash = await hashData(contentText.value);
    } else {
      if (!contentFile.value) {
        return { status: "error", message: "Upload a file to compare." };
      }
      const bytes = await contentFile.value.arrayBuffer();
      providedHash = await hashBytes(bytes);
    }

    if (providedHash === proof.payload.contentHash) {
      return {
        status: "match",
        message: "Content hash matches proof payload.",
        providedHash,
      };
    }

    return {
      status: "mismatch",
      message: "Content hash does not match proof payload.",
      providedHash,
    };
  } catch (caught) {
    const message = caught instanceof Error ? caught.message : String(caught);
    return { status: "error", message };
  }
};

const onVerify = async () => {
  isVerifying.value = true;
  parsedProof.value = null;
  stageOne.value = { status: "idle", errors: [] };
  stageTwo.value = { status: "idle" };

  try {
    const rawProof = await loadProofJson();
    const parsed = parsePortableProofJson(rawProof);

    if (!parsed.ok || !parsed.proof) {
      stageOne.value = {
        status: "invalid",
        errors: parsed.errors,
      };
      stageTwo.value = { status: "skipped", message: "Content validation skipped because proof is invalid." };
      return;
    }

    const signatureCheck = await verifyPortableProofSignature(parsed.proof);

    if (!signatureCheck.ok) {
      stageOne.value = {
        status: "invalid",
        errors: signatureCheck.errors,
      };
      stageTwo.value = { status: "skipped", message: "Content validation skipped because signature is invalid." };
      return;
    }

    parsedProof.value = parsed.proof;

    stageOne.value = {
      status: "valid",
      errors: [],
      fingerprint: parsed.proof.fingerprint,
      contentHash: parsed.proof.payload.contentHash,
    };

    stageTwo.value = await verifyContentMatch(parsed.proof);
  } catch (caught) {
    const message = caught instanceof Error ? caught.message : String(caught);
    stageOne.value = {
      status: "invalid",
      errors: [message],
    };
    stageTwo.value = { status: "skipped", message: "Content validation skipped because proof could not be processed." };
  } finally {
    isVerifying.value = false;
  }
};
</script>

<template>
  <section class="space-y-5">
    <header>
      <h2 class="m-0 text-2xl">Verify</h2>
      <p class="mt-2 text-sm text-fg-muted">Verify proof validity and optional content match offline.</p>
    </header>

    <SCard class="space-y-4 p-5">
      <h3 class="m-0 text-lg">Proof input</h3>
      <input type="file" accept=".json,application/json,text/plain" @change="onProofFileInput" />
      <textarea
        v-model="proofJsonInput"
        class="min-h-44 w-full rounded-md border border-border bg-surface px-3 py-2 font-mono text-xs"
        placeholder="Paste proof JSON"
      />

      <div class="space-y-2 text-sm">
        <p class="m-0 font-semibold">Verification mode</p>
        <label class="mr-4 inline-flex items-center gap-2">
          <input v-model="verificationMode" type="radio" value="proof-only" />
          Verify proof only
        </label>
        <label class="inline-flex items-center gap-2">
          <input v-model="verificationMode" type="radio" value="proof-and-content" />
          Verify proof + original content
        </label>
      </div>

      <div v-if="verificationMode === 'proof-and-content'" class="space-y-3 rounded-md border border-border p-3">
        <div class="space-y-2 text-sm">
          <label class="mr-4 inline-flex items-center gap-2">
            <input v-model="contentMode" type="radio" value="text" />
            Text
          </label>
          <label class="inline-flex items-center gap-2">
            <input v-model="contentMode" type="radio" value="file" />
            File
          </label>
        </div>

        <textarea
          v-if="contentMode === 'text'"
          v-model="contentText"
          class="min-h-36 w-full rounded-md border border-border bg-surface px-3 py-2"
          placeholder="Paste original text"
        />

        <input v-else type="file" @change="onContentFileInput" />
      </div>

      <SButton variant="primary" :loading="isVerifying" @click="onVerify">
        {{ isVerifying ? "Verifying..." : "Verify" }}
      </SButton>
    </SCard>

    <SCard class="space-y-3 p-5" :class="stageOneTone">
      <h3 class="m-0 text-lg">Stage 1 — Proof validation</h3>
      <p v-if="stageOne.status === 'idle'" class="m-0 text-sm text-fg-muted">No verification run yet.</p>
      <p v-if="stageOne.status === 'valid'" class="m-0 text-sm">Signature valid.</p>

      <ul v-if="stageOne.status === 'invalid'" class="m-0 list-disc pl-5 text-sm">
        <li v-for="message in stageOne.errors" :key="message">{{ message }}</li>
      </ul>

      <div v-if="stageOne.status === 'valid'" class="grid gap-2 text-sm">
        <div><strong>Signer fingerprint:</strong> <span class="font-mono text-xs">{{ stageOne.fingerprint }}</span></div>
        <div><strong>Content hash:</strong> <span class="font-mono text-xs">{{ stageOne.contentHash }}</span></div>
      </div>
    </SCard>

    <SCard class="space-y-3 p-5" :class="stageTwoTone">
      <h3 class="m-0 text-lg">Stage 2 — Content validation</h3>
      <p v-if="stageTwo.status === 'idle'" class="m-0 text-sm text-fg-muted">No content validation run yet.</p>
      <p v-else class="m-0 text-sm">{{ stageTwo.message }}</p>

      <div v-if="stageTwo.providedHash" class="text-sm">
        <strong>Provided content hash:</strong>
        <span class="font-mono text-xs">{{ stageTwo.providedHash }}</span>
      </div>
    </SCard>
  </section>
</template>
