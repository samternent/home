<script setup lang="ts">
import { computed, ref } from "vue";
import { SButton, SCard } from "ternent-ui/components";
import { hashBytes, hashData } from "ternent-utils";
import { useIdentitySession } from "@/modules/identity";
import {
  createPortableProof,
  SUPPORTED_HASH_ALGORITHM,
  SUPPORTED_SIGNATURE_ALGORITHM,
  type PortableProofV1,
} from "@/modules/proof";

type SignMode = "text" | "file";

const { identity, hasIdentity } = useIdentitySession();

const mode = ref<SignMode>("text");
const textContent = ref("");
const textContentName = ref("");
const selectedFile = ref<File | null>(null);
const isDragging = ref(false);
const isSigning = ref(false);

const error = ref<string | null>(null);
const notice = ref<string | null>(null);
const signedProof = ref<PortableProofV1 | null>(null);
const outputFileName = ref<string | null>(null);
const showProofJson = ref(false);

const canSign = computed(() => {
  if (!hasIdentity.value) return false;
  if (mode.value === "text") return textContent.value.trim().length > 0;
  return Boolean(selectedFile.value);
});

const proofJson = computed(() => {
  if (!signedProof.value) return "";
  return JSON.stringify(signedProof.value, null, 2);
});

const onFileInput = (event: Event) => {
  const input = event.target as HTMLInputElement;
  selectedFile.value = input.files?.[0] || null;
};

const onDrop = (event: DragEvent) => {
  event.preventDefault();
  isDragging.value = false;
  const dropped = event.dataTransfer?.files?.[0] || null;
  selectedFile.value = dropped;
};

const onDragOver = (event: DragEvent) => {
  event.preventDefault();
  isDragging.value = true;
};

const onDragLeave = () => {
  isDragging.value = false;
};

const downloadProof = () => {
  if (!proofJson.value) return;

  const name = outputFileName.value || "portable-proof";
  const blob = new Blob([proofJson.value], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${name}.proof.json`;
  anchor.click();
  URL.revokeObjectURL(url);
};

const onSign = async () => {
  error.value = null;
  notice.value = null;
  signedProof.value = null;

  if (!identity.value) {
    error.value = "No identity loaded. Load an identity before signing.";
    return;
  }

  isSigning.value = true;

  try {
    let contentHash = "";
    let canonicalization: "ternent-utils/canonicalStringify-v1" | "raw-bytes" = "raw-bytes";
    let fileName = textContentName.value.trim() || "text-proof";

    if (mode.value === "text") {
      if (!textContent.value.trim()) {
        throw new Error("Text content is empty.");
      }

      contentHash = await hashData(textContent.value);
      canonicalization = "ternent-utils/canonicalStringify-v1";
    } else {
      if (!selectedFile.value) {
        throw new Error("Select a file before signing.");
      }

      const bytes = await selectedFile.value.arrayBuffer();
      contentHash = await hashBytes(bytes);
      canonicalization = "raw-bytes";
      fileName = selectedFile.value.name;
    }

    const proof = await createPortableProof({
      identity: identity.value,
      payload: {
        contentHash,
        hashAlgorithm: SUPPORTED_HASH_ALGORITHM,
        signatureAlgorithm: SUPPORTED_SIGNATURE_ALGORITHM,
        canonicalization,
      },
    });

    signedProof.value = proof;
    outputFileName.value = fileName;
    notice.value = "Proof created successfully.";
  } catch (caught) {
    error.value = caught instanceof Error ? caught.message : "Failed to sign content.";
  } finally {
    isSigning.value = false;
  }
};
</script>

<template>
  <section class="space-y-5">
    <header>
      <h2 class="m-0 text-2xl">Sign</h2>
      <p class="mt-2 text-sm text-fg-muted">Sign text or one file and export a portable proof JSON.</p>
    </header>

    <SCard v-if="!hasIdentity" class="space-y-3 p-5">
      <h3 class="m-0 text-lg">No identity loaded</h3>
      <p class="m-0 text-sm text-fg-muted">Load an identity before signing content.</p>
      <SButton variant="secondary" to="/app/identity">Go to Identity</SButton>
    </SCard>

    <template v-else>
      <SCard class="space-y-4 p-5">
        <div class="flex gap-2">
          <SButton :variant="mode === 'text' ? 'primary' : 'secondary'" @click="mode = 'text'">Sign Text</SButton>
          <SButton :variant="mode === 'file' ? 'primary' : 'secondary'" @click="mode = 'file'">Sign File</SButton>
        </div>

        <div v-if="mode === 'text'" class="space-y-3">
          <input
            v-model="textContentName"
            class="w-full rounded-md border border-border bg-surface px-3 py-2 text-sm"
            placeholder="Optional content name"
          />
          <textarea
            v-model="textContent"
            class="min-h-52 w-full rounded-md border border-border bg-surface px-3 py-2"
            placeholder="Enter text to sign"
          />
        </div>

        <div v-else class="space-y-3">
          <label
            class="block rounded-lg border-2 border-dashed p-6 text-center text-sm"
            :class="isDragging ? 'border-primary bg-primary-muted' : 'border-border bg-surface'"
            @drop="onDrop"
            @dragover="onDragOver"
            @dragleave="onDragLeave"
          >
            <input type="file" class="hidden" @change="onFileInput" />
            Drag a file here or click to choose one
          </label>

          <input type="file" @change="onFileInput" />

          <p v-if="selectedFile" class="m-0 text-sm text-fg-muted">
            Selected: {{ selectedFile.name }} ({{ selectedFile.size }} bytes)
          </p>
        </div>

        <SButton variant="primary" :disabled="!canSign" :loading="isSigning" @click="onSign">
          {{ isSigning ? "Signing..." : "Sign" }}
        </SButton>
      </SCard>

      <SCard v-if="signedProof" class="space-y-4 p-5">
        <h3 class="m-0 text-xl">Proof ready</h3>
        <div class="grid gap-2 text-sm">
          <div><strong>Content hash:</strong> <span class="font-mono text-xs">{{ signedProof.payload.contentHash }}</span></div>
          <div><strong>Signer fingerprint:</strong> <span class="font-mono text-xs">{{ signedProof.fingerprint }}</span></div>
          <div v-if="outputFileName"><strong>Name:</strong> {{ outputFileName }}</div>
        </div>

        <div class="flex flex-wrap gap-2">
          <SButton variant="primary" @click="downloadProof">Download proof JSON</SButton>
          <SButton variant="secondary" @click="showProofJson = !showProofJson">
            {{ showProofJson ? "Hide proof JSON" : "View proof JSON" }}
          </SButton>
        </div>

        <textarea
          v-if="showProofJson"
          class="min-h-64 w-full rounded-md border border-border bg-surface px-3 py-2 font-mono text-xs"
          readonly
          :value="proofJson"
        />
      </SCard>
    </template>

    <p v-if="notice" class="m-0 rounded-md border border-border bg-surface px-3 py-2 text-sm">{{ notice }}</p>
    <p v-if="error" class="m-0 rounded-md border border-danger bg-danger-muted px-3 py-2 text-sm">{{ error }}</p>
  </section>
</template>
