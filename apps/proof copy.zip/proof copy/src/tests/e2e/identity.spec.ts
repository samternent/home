import { test, expect } from "@playwright/test";

test("generate identity, sign text, verify proof and mismatch", async ({ page }) => {
  await page.goto("/app/identity");
  await page.getByRole("checkbox", { name: "Remember identity in this browser" }).check();
  await page.getByRole("button", { name: "Generate new identity" }).click();
  await expect(page.getByText("Identity created. Export it now and store it securely.")).toBeVisible();

  await page.goto("/app/sign");
  await page.getByRole("button", { name: "Sign Text" }).click();
  await page.getByPlaceholder("Enter text to sign").fill("portable proof text");
  await page.getByRole("button", { name: "Sign", exact: true }).click();
  await expect(page.getByText("Proof created successfully.")).toBeVisible();

  await page.getByRole("button", { name: "View proof JSON" }).click();
  const proofJson = await page.locator("textarea[readonly]").inputValue();

  await page.goto("/app/verify");
  await page.getByPlaceholder("Paste proof JSON").fill(proofJson);
  await page.getByRole("radio", { name: "Verify proof + original content" }).check();
  await page.getByRole("radio", { name: "Text" }).check();
  await page.getByPlaceholder("Paste original text").fill("portable proof text");
  await page.getByRole("button", { name: "Verify" }).click();

  await expect(page.getByText("Signature valid.")).toBeVisible();
  await expect(page.getByText("Content hash matches proof payload.")).toBeVisible();

  await page.getByPlaceholder("Paste original text").fill("different text");
  await page.getByRole("button", { name: "Verify" }).click();
  await expect(page.getByText("Content hash does not match proof payload.")).toBeVisible();
});
