<script setup lang="ts">
import { computed } from "vue";
import { useOfflineSync } from "@/modules/offline";

const { isOnline } = useOfflineSync();

const bannerText = computed(() => {
  return isOnline.value
    ? "Online. The app shell is cached for offline use."
    : "Offline mode active. Signing and verification continue locally.";
});
</script>

<template>
  <div
    class="rounded-md border px-3 py-2 text-sm"
    :class="isOnline ? 'bg-surface border-border text-fg-muted' : 'bg-danger-muted border-danger text-fg'"
  >
    {{ bannerText }}
  </div>
</template>
